package com.cg.qgs.dao;

public interface QueryConstants {
	
	String VALIDATE_USER_QUERY = "select * from userrole where username = ? and password = ?";
	
	String GET_ROLECODE = "select rolecode from userrole where username = ? and password = ?";
	
	String ACCOUNT_CREATION = "insert into accounts values(?,?,?,?,?,?,?,?)";
	
	String GET_LOB_NAME = "select bus_seg_id from businesssegment where bus_seg_name = ?";
	
	String ADD_USER = "insert into userRole values(?,?,?)";
	
	String USER_EXISTS = "select * from userrole where username = ?";
	
	String GET_BUS_SEG_ID = "select businesssegmentid from accounts where accountnumber = ?";
	
	String GET_POLICY_QUESTIONS = "select * from policyquestions where bus_seg_id = ?";
	
	String VALIDATE_ACCOUNT_QUERY ="select * from accounts where username =?";
}
