package com.cg.qgs.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.Policy_Questions;
import com.cg.qgs.model.UserRole;
import com.cg.qgs.utility.JdbcUtility;

public class AdminDAO implements IAdminDAO{

	static Connection connection = null;
	static PreparedStatement prepareStatement = null;
	static ResultSet resultSet = null;

	public boolean loginValidation(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(QueryConstants.VALIDATE_USER_QUERY);
			prepareStatement.setString(1, username);
			prepareStatement.setString(2, password);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
				String name = resultSet.getString(1);
				String pwd = resultSet.getString(2);
			}
			else {
				System.out.println("no user");
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;
	}

	@Override
	public String getRoleCode(String username, String password) throws QGSException {
		// TODO Auto-generated method stub
		String roleCode = "";
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(QueryConstants.GET_ROLECODE);
			prepareStatement.setString(1, username);
			prepareStatement.setString(2, password);
			// ps.setInt(1, 1);
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			if(found == true) {
				roleCode = resultSet.getString("rolecode");
				//System.out.println(name + " " + pwd);
				System.out.println(roleCode);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return roleCode;
	}
	
	
	
	@Override
	public int accountCreation(Accounts account,String userName) throws QGSException {
		// TODO Auto-generated method stub

		connection = JdbcUtility.getConnection();
		int isInserted = 0;
		try {
			prepareStatement = connection.prepareStatement(QueryConstants.ACCOUNT_CREATION);
			prepareStatement.setInt(1, account.getAccountNumber());
			prepareStatement.setString(2, account.getInsuredName());
			prepareStatement.setString(3, account.getInsuredStreet());
			prepareStatement.setString(4, account.getInsuredCity());
			prepareStatement.setString(5, account.getInsuredState());
			prepareStatement.setInt(6, account.getInsuredZip());
			prepareStatement.setString(7, account.getLineOfBusiness());
			prepareStatement.setString(8, userName);
			
			isInserted = prepareStatement.executeUpdate();
			

		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				resultSet.close();
				prepareStatement.close();
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		
		return isInserted;
	}

	@Override
	public String getLineOfBusinessIdByName(String lineOfBusinessName) throws QGSException {
		String businessSegmentId = null;
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(QueryConstants.GET_LOB_NAME);
			prepareStatement.setString(1, lineOfBusinessName);
			
			resultSet = prepareStatement.executeQuery();
			found = resultSet.next();
			if(found == true) {
				businessSegmentId = resultSet.getString(1);
				//System.out.println(name + " " + pwd);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		return businessSegmentId;
	}
	
	@Override
	public int addUser(UserRole userRole) throws QGSException {
		// TODO Auto-generated method stub
		int isInserted = 0;
		try
		{
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(QueryConstants.ADD_USER);
			prepareStatement.setString(1, userRole.getUserName());
			prepareStatement.setString(2, userRole.getPassword());
			prepareStatement.setString(3, userRole.getRoleCode());
			isInserted = prepareStatement.executeUpdate();
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		finally {
			try
			{
				prepareStatement.close();
				connection.close();
			}
			catch (Exception e) {
				System.out.println("user name already exist");
			}
		}
		return isInserted;
	}

	@Override
	public boolean isUserExists(String userName) throws QGSException {
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(QueryConstants.USER_EXISTS);
			prepareStatement.setString(1, userName);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;
	}

	@Override
	public String getBusSegId(int accNumber) throws QGSException {
		// TODO Auto-generated method stub
		String busSegId = null;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(QueryConstants.GET_BUS_SEG_ID);
			prepareStatement.setInt(1, accNumber);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				busSegId = resultSet.getString(1);
				System.out.println("Getting business segment id :" + busSegId);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return busSegId;
	}

	@Override
	public List<Policy_Questions> getPolicyQuestions(String busSegId) throws QGSException {
		List<Policy_Questions> policyQuestions = new ArrayList<Policy_Questions>();
		Policy_Questions polQues = null;
		try {
			connection = JdbcUtility.getConnection();
			System.out.println(busSegId);
			prepareStatement = connection.prepareStatement(QueryConstants.GET_POLICY_QUESTIONS);
			prepareStatement.setString(1, busSegId);
			resultSet = prepareStatement.executeQuery();
			while(resultSet.next()) {
				polQues = new Policy_Questions();
				polQues.setPolQuesId(resultSet.getString(1));
				polQues.setPolQuesSeq(resultSet.getInt(2));
				polQues.setBusSegId(resultSet.getString(3));
				polQues.setPolQuesDesc(resultSet.getString(4));
				polQues.setPolQuesAns1(resultSet.getString(5));
				polQues.setPolQuesAns1Weightage(resultSet.getInt(6));
				polQues.setPolQuesAns2(resultSet.getString(7));
				polQues.setPolQuesAns2Weightage(resultSet.getInt(8));
				polQues.setPolQuesAns3(resultSet.getString(9));
				polQues.setPolQuesAns3Weightage(resultSet.getInt(10));
				//System.out.println("Im in limelight : "+polQues);
				policyQuestions.add(polQues);
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object"+e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
		System.out.println(policyQuestions);
		return policyQuestions;
	}
	/*public static void main(String[] args) throws QGSException {
		List<String> policyQuestions = new ArrayList<String>();
		policyQuestions = getPolicyQuestions("BA01");
		for(String pq : policyQuestions) {
			System.out.println(pq);
		}
	}*/

	@Override
	public List<String> getPolicyAnswers(String busSegId) throws QGSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean accountValidation(String username) throws QGSException {
		// TODO Auto-generated method stub
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();

			prepareStatement = connection.prepareStatement(QueryConstants.VALIDATE_ACCOUNT_QUERY);
			prepareStatement.setString(1, username);
			
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
				String name = resultSet.getString(1);
				
			}
			else {
				System.out.println("No Account so please create one");
			}
		} catch (SQLException e) {
			throw new QGSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new QGSException("problem while closing");
			}

		}
        return found;
	}
}
