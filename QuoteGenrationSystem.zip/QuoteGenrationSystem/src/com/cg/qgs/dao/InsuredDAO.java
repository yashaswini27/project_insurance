package com.cg.qgs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.qgs.exceptions.QGSException;
import com.cg.qgs.utility.JdbcUtility;

public class InsuredDAO {
	static Connection con = null;
	static PreparedStatement ps =null;
	static ResultSet rs=null;
	public static boolean accountValidationInsured(String username,String password) throws QGSException {
		boolean found=false;
		try {
			con = JdbcUtility.getConnection();
			String sql = "select username from userrole  where username in (select username from accounts)";
			ps=con.prepareStatement(sql);
	rs=	ps.executeQuery();
			if(rs.next()) {
				found=true;
			}
		}
			 catch (SQLException e) {
				throw new QGSException("problem while creating PS object");
			} finally {
				try {
					con.close();
				} catch (SQLException e) {
					throw new QGSException("problem while closing");
				}

			}
	        return found;
				
			}
			
			
		}


